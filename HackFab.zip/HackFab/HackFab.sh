bash .banner
echo "Que deseas crackear:"
echo ""
echo "==============="
echo "1)Facebook    ="
echo "2)Twitter     ="
echo "3)Outlook     ="
echo "4)Gmail       ="
echo "5)Yahoo       ="
echo "6)PayPal      ="
echo "================================="
bash .elp
read input
bash .$input
