 __    __            _______     __  __      __
|  \  |  \          |       \   |  \|  \    /  \
| $$\ | $$  ______  | $$$$$$$\ _| $$_\$$\  /  $$__    __
| $$$\| $$ /      \ | $$__/ $$|   $$ \\$$\/  $$|  \  /  \
| $$$$\ $$|  $$$$$$\| $$    $$ \$$$$$$ \$$  $$  \$$\/  $$
| $$\$$ $$| $$    $$| $$$$$$$   | $$ __ \$$$$    >$$  $$
| $$ \$$$$| $$$$$$$$| $$        | $$|  \| $$    /  $$$$\
| $$  \$$$ \$$     \| $$         \$$  $$| $$   |  $$ \$$\
 \$$   \$$  \$$$$$$$ \$$          \$$$$  \$$    \$$   \$$

Este repositorio esta hecho
con fines educativos no nos hacemos responsavles
por el uso inadecuado que se les de
ni tampoco aceptamos reclamos.

