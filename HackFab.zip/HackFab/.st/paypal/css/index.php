<?

header("Location: /");

?>