<?php
$TO = "your.email@here.com";
?>